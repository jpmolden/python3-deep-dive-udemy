# boolean.pu

# List of symbols that we export from the package
__all__ = ['is_boolean']


def is_boolean(arg):
    pass

def bolean_helper():
    pass

def boolean_helper_2():
    pass



