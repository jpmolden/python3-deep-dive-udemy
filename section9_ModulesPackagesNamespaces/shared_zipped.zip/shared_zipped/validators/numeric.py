# numeric.py

__all__ = ['is_integer']

def is_integer(arg):
    pass

def is_numeric(arg):
    pass

def _numeric_helper_1():
    pass

def _numeric_helper_2():
    pass


