# date.py

__all__ = ['is_date']

def is_date(arg):
    pass

def _date_helper():
    pass

def _date_helper_2():
    pass



