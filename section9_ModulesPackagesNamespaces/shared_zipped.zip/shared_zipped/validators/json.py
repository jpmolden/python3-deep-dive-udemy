# json.py

__all__ = ['is_json']

def is_json(arg):
    pass

def _json_helper():
    pass

def _json_helper_2():
    pass



